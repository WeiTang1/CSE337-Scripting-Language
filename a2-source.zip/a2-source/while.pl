#!/usr/bin/perl 
use strict;
use warnings;

my $count = 0;

while ($count <5){
  print "HELLO\n";
  $count ++;
}
